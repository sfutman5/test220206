﻿using System;

namespace ConsoleApp13
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             Input                Hello
             Output     Letter: ‘l’ Count: 2
            */

            Console.Write("Enter the word to analayze:");
            string str = Console.ReadLine();
            string strRt;
            strRt = checkString(str);
            Console.WriteLine("  ");
            Console.WriteLine("Return value: " + strRt + "  ");
        }


        public static string checkString(string str)
        {

            char sr;
            int i, k, freq = 0, flag = 0;
            int max1 = int.MinValue;
            int max2 = int.MinValue;
            char Smax1;
            char Smax2;

            Smax1 = char.Parse("X");

            for (k = 0; k < str.Length; k++)
            {

                freq = 0;
                flag = 0;

                sr = char.Parse(str[k].ToString());
                if (!char.IsUpper(sr))
                {
                    for (i = 0; i < str.Length; i++)
                    {
                        if (str[i] == sr)
                        {
                            flag = 1;
                            freq++;
                        }
                    }
                    if (flag == 1)
                    {
                        //Console.WriteLine("Character " + sr + " Ocurred " + freq + " times ");
                        if (freq > max1)
                        {
                            max2 = max1;
                            max1 = freq;

                            Smax2 = Smax1;
                            Smax1 = sr;
                        }
                        else if (freq > max2)
                        {
                            max2 = freq;

                            Smax2 = sr;
                        }
                    }




                }

            }

            return "Letter: " + Smax1.ToString() + " Count: " + max1.ToString();
        }

    }
}
