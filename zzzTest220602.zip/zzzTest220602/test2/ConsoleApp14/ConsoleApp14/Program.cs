﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace ConsoleApp14
{
    class Program
    {
        static void Main(string[] args)
        {
            int counter = -1;
            string[] lineX = new string[290];

            //at the end Check the file where the program runs example C:\Users\RCORR\source\repos\ConsoleApp11\ConsoleApp11\bin\Debug\netcoreapp3.1

            //// Read the file and display it line by line.  
            //foreach (string line in System.IO.File.ReadLines(@"c:\USCities.txt")) // 
            //{
            //    System.Console.WriteLine(line);
            //    lineX[counter] = line;
            //    counter++;

            //}
            //File.WriteAllLines("zFinalCities.txt", lineX);

            //System.Console.WriteLine("There were {0} lines.", counter);
            //// Suspend the screen.  
            //System.Console.ReadLine();


            StreamReader archivoA = File.OpenText(@"c:\USCities.txt");
            StreamReader archivoB = File.OpenText(@"c:\CACities.txt");

            string lineaA = null;
            string lineaB = null;
            int iA = 0;
            int iB = 0;
            Boolean B_evaluated = false;

            iB++;
            lineaB = archivoB.ReadLine();

            while (!archivoA.EndOfStream)
            {
                if (lineaA == null)
                {
                    iA++;
                    lineaA = archivoA.ReadLine();
                }

                if (archivoB.EndOfStream && B_evaluated)
                {
                    counter++;
                    lineX[counter] = lineaA;
                    lineaA = null;
                }

                //WICHITA
                //WINNIPEG
                //if(lineaA== "WICHITA" || lineaA == "WINNIPEG" || lineaB == "WICHITA" || lineaB == "WINNIPEG")
                //if ( lineaA == "WINSTON-SALEM" || lineaB == "WINSTON-SALEM")
                //    {
                //    break;
                //}

                while (!archivoB.EndOfStream || B_evaluated == false)
                {
                    // iB++;
                    // lineaB = archivoB.ReadLine();

                    int comparison = String.Compare(lineaA.ToLower(), lineaB.ToLower(), comparisonType: StringComparison.OrdinalIgnoreCase);
                    if (comparison < 0 && B_evaluated == false)
                    {
                        B_evaluated = false;// we need at least one Win
                    }
                    else
                    {
                        B_evaluated = true; // here is the Win of last B_evaluated
                    }

                    if (comparison < 0)
                    {
                        //Console.WriteLine($"<{lineaA}> is less than <{lineaB}>");
                        counter++;
                        lineX[counter] = lineaA;
                        lineaA = null; //con este null forzamos a que vuelva a leer cuando amerite

                        break; //para salir del while
                    }
                    else if (comparison > 0)
                    {
                        //Console.WriteLine($"<{lineaA}> is greater than <{lineaB}>");
                        counter++;
                        lineX[counter] = lineaB;

                        iB++;
                        lineaB = archivoB.ReadLine();
                        if (lineaB == null)
                        {
                            B_evaluated = true;
                        }
                        else
                        {
                            B_evaluated = false;
                        }
                    }
                    else
                    {
                        //Console.WriteLine($"<{lineaA}> and <{lineaB}> are equivalent in order");
                        counter++;
                        lineX[counter] = lineaA;
                        lineaA = null;

                        counter++;
                        lineX[counter] = lineaB;

                        iB++;
                        lineaB = archivoB.ReadLine();
                        if (lineaB == null)
                        {
                            B_evaluated = true;
                        }
                        else
                        {
                            B_evaluated = false;
                        }

                        break; //para salir del while
                    }

                }

            }

            File.WriteAllLines("zFinalCities.txt", lineX);
            System.Console.ReadLine();

            /*
             usa
            ABILENE
            AKRON
            ALBANY
            ALBUQUERQUE
            ALEXANDRIA
            ALLENTOWN

            Cn
            ABBOTSFORD
            AMOS
            BAIE VERTE
            BAIE-COMEAU
            BAIE-SAINT-PAUL
            BELLETERRE
             */
        }
    }
}
